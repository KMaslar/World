//
//  HelloWorld.h
//  HelloWorld
//
//  Created by Kostadina Gecevska on 24.6.24.
//

#import <Foundation/Foundation.h>

//! Project version number for HelloWorld.
FOUNDATION_EXPORT double HelloWorldVersionNumber;

//! Project version string for HelloWorld.
FOUNDATION_EXPORT const unsigned char HelloWorldVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HelloWorld/PublicHeader.h>


